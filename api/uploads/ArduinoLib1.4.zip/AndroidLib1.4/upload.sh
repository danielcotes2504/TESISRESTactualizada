#!/bin/bash
/usr/local/bin/platformio -f -c netbeans run -t upload
sleep 1
screen /dev/cu.usbmodem1421 9600

