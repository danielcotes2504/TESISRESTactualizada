#ifndef UAOIOT_CLIENT_H
#define UAOIOT_CLIENT_H

#ifndef MQTT_BUFFER_SIZE
#define MQTT_BUFFER_SIZE 128
#endif

#define MQTTCLIENT_QOS1 0
#define MQTTCLIENT_QOS2 0

#include <Arduino.h>
#include <Client.h>
#include <Stream.h>
#include "lib/MQTTClient.h"
#include "Network.h"
#include "Timer.h"
#include <Process.h>
typedef struct {
    char * topic;
    char * payload;
    unsigned int length;
    boolean retained;
} MQTTMessage;

void onPublishDataArrive(String messageType, String objectId, int registerCount);

class UAOIOTClient {
private:
  Network network;
  MQTT::Client<Network, Timer, MQTT_BUFFER_SIZE, 0> * client;
  MQTTPacket_connectData options;
  const char * hostname;
  int port;
  boolean debugPrinter;
  unsigned long lastMillis1, lastMillis2,lastMillis3;
  String username,password,clientId;
  double tempRegisters[28];
  Process wifiCheck;
public:
  UAOIOTClient();
  static double registers[128];
  boolean connect(const char * hostname, const char * objectId, const char* username, const char* password);
  int getRegisterValue(int index){
    return UAOIOTClient::registers[index];
  };
  boolean publishRegisters(String messageType, String remoteObjectId,int registerCount);
  void setTempRegisterValue(int index,double value);
  void loop();
  void wifiStatus();
  boolean connected();
  boolean disconnect();
  void setDebugPrinter(boolean _debugPrinter);
};

#endif
