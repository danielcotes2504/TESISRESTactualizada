
#include "UAOIOTClient.h"
#include <Bridge.h>
#include <BridgeClient.h>

BridgeClient networkClient;

double UAOIOTClient::registers[128];

void MQTTClient_messageHandler(MQTT::MessageData &messageData) {
  MQTT::Message &message = messageData.message;
  char * payload = (char *)message.payload;
  char * messageType;
  int len = messageData.topicName.lenstring.len;
  char topic[len+1];
  memcpy(topic, messageData.topicName.lenstring.data, (size_t)len);
  topic[len] = '\0';
  messageType = strtok(topic, "_");
  char * srcObject;
  char * value;
  value= strtok(payload, ";");
  srcObject=value;
  int registerLength=0;
  
  while (value) {
    value = strtok(NULL, ";");
    UAOIOTClient::registers[registerLength]= atoi(value);
    registerLength++;
  }

  if(String(messageType)=="broadcast"){
    onPublishDataArrive(messageType,srcObject,registerLength);
  }
  
  if(String(messageType)=="unicast"){
    onPublishDataArrive(messageType,srcObject,registerLength);
  }

}

UAOIOTClient::UAOIOTClient(){

}


boolean UAOIOTClient::connect(const char * _hostname, const char * _objectId, const char * _username, const char * _password) {
  username=_username;
  clientId=_objectId;
  password=_password;
  // this->begin(hostname, 1883, _client1);
  if(this->debugPrinter){
    Serial.println("Inicializando el modo bridge");
  }
  Bridge.begin();
  if(this->debugPrinter){
    Serial.println("Modo Bridge Inicializado.");
  }

  this->client = new MQTT::Client<Network, Timer, MQTT_BUFFER_SIZE, 0>(this->network);
  this->network.setClient(&networkClient);
  this->client->setDefaultMessageHandler(MQTTClient_messageHandler);
  this->options = MQTTPacket_connectData_initializer;
  this->hostname = _hostname;
  this->port = 1883;
  while(!this->client->isConnected()){
    if(this->network.connect((char*)this->hostname, this->port)){
      String sClientId=username+"_"+clientId;
      this->options.clientID.cstring = (char*) sClientId.c_str();

      if(username && password) {
        this->options.username.cstring = (char*)username.c_str();
        this->options.password.cstring = (char*)password.c_str();
      }
      this->options.cleansession=true;
      if(this->client->connect(this->options) == MQTT::SUCCESS){
        String broadcast="broadcast_" + String(this->options.username.cstring);
        String unicast="unicast_" + String(this->options.username.cstring) + "_" + _objectId;
        client->subscribe(broadcast.c_str(), MQTT::QOS0, NULL);
        client->subscribe(unicast.c_str(), MQTT::QOS0, NULL);
        return true;
      }else{
        return false;
      }
    }
    loop();
  }
}

void UAOIOTClient::setTempRegisterValue(int index,double value){
  this->tempRegisters[index]=value;
}


boolean UAOIOTClient::publishRegisters(String messageType, String remoteObjectId,int registerCount){
  String payload = this->clientId+";";
  for (int i = 0; i < registerCount; i++) {
    payload += String(tempRegisters[i]) + ";";
  }
  MQTT::Message message;
  message.qos = MQTT::QOS0;
  message.retained = false;
  message.dup = false;
  message.payload = (char*)payload.c_str();
  message.payloadlen = (unsigned int)strlen((char*)payload.c_str());
  String topic;
  if(messageType=="broadcast"){
    topic = "broadcast_" + this->username;

  }

  if(messageType=="unicast"){
    topic = "unicast_" + this->username + "_" + remoteObjectId;
  }

  return client->publish(topic.c_str(), message) == MQTT::SUCCESS;
}

boolean UAOIOTClient::connected() {
  return this->client->isConnected();
}

boolean UAOIOTClient::disconnect() {
  return this->client->disconnect() == MQTT::SUCCESS;
}

void UAOIOTClient::loop() {
  if(this->debugPrinter){
    if(millis() - this->lastMillis1 > 1000) {
      this->lastMillis1 = millis();
      if(this->client->isConnected()){
        Serial.println("conectado al broker");
      }else{
        Serial.println("no-conectado al broker");
      }
    }
  }
  boolean isConnected=false;
  if (millis() - this->lastMillis2 > 5000) {
    this->lastMillis2 = millis();
    this->wifiCheck.runShellCommand("/usr/bin/pretty-wifi-info.lua | grep Signal:");
    while (this->wifiCheck.running());
    int result = 0;
    if (this->wifiCheck.available() > 0) {
      result = this->wifiCheck.parseInt();
    }
    if (result > 0) {
      isConnected = true;
    } else {
      this->client->disconnect();
      isConnected = false;
    }
    if(this->debugPrinter){
      if(isConnected){
        Serial.println("WIFI-conectado");
      }else{
        Serial.println("WIFI-no-conectado");
      }
    }
  }


  if(!this->network.connected() && this->client->isConnected()) {
    // the following call will not send a packet but reset the instance
    // to allow proper reconnection
    this->client->disconnect();
  }

  this->client->yield();
}

void UAOIOTClient::setDebugPrinter(boolean _debugPrinter){
  this->debugPrinter=_debugPrinter;
}

void UAOIOTClient::wifiStatus(){
  if(millis() - this->lastMillis2 > 1000) {
    this->lastMillis2 = millis();
    this->wifiCheck.runShellCommand("/usr/bin/pretty-wifi-info.lua");
    while (this->wifiCheck.available() > 0) {
      char c = this->wifiCheck.read();
      Serial.print(c);
    }
  }
}
