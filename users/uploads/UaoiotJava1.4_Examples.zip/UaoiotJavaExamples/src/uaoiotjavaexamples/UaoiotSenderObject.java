package uaoiotjavaexamples;

import co.edu.uao.uaoiot.javauaoiotlib.UaoiotClient;
import java.util.Random;
import org.eclipse.paho.client.mqttv3.MqttException;

/**
 * Esta clase es usada para realizar una prueba de conexión Java con el servidor
 * UAOIOT
 *
 * @author Jhon Eder Portocarrero
 * @version 1.4
 */
public class UaoiotSenderObject {

    public static void main(String[] args) throws MqttException {
        final UaoiotClient uaoiotClient = new UaoiotClient();;
        uaoiotClient.connect("181.118.150.149", "javasender", "grupo1", "123456");
        
        System.out.println("conectado al servidor");

        new Thread() {
            @Override
            public void run() {

                Random rand=new Random();
                while (true) {
                    if (uaoiotClient.isClientConnected()) {
                        uaoiotClient.setTempRegisterValue(0, rand.nextInt(2));
                        uaoiotClient.setTempRegisterValue(1, rand.nextDouble()*100);
                        uaoiotClient.publishRegisters(UaoiotClient.UNICAST_MESSAGE_TYPE,"ard01", 2);
                        System.out.print("Enviado = [");
                        for (int j = 0; j < 2; j++) {
                            System.out.print(uaoiotClient.getTempRegistersValue(j) + " | ");
                        }
                        System.out.println("]");

                        try {
                            Thread.sleep(1000);
                        } catch (InterruptedException ex) {

                        }

                    }
                }
            }
        }.start();

    }

}
