package uaoiotjavaexamples;

import co.edu.uao.uaoiot.javauaoiotlib.UaoiotClient;
import org.eclipse.paho.client.mqttv3.MqttException;

/**
 * Esta clase es usada para realizar una prueba de conexión Java con el servidor
 * UAOIOT
 *
 * @author Jhon Eder Portocarrero
 * @version 1.4
 *
 */
public class UaoiotReceiverObject {

    public static void main(String[] args) throws MqttException {
        final UaoiotClient uaoiotClient = new UaoiotClient();;
        uaoiotClient.connect("181.118.150.149", "javareceiver", "grupo1", "123456");
        System.out.println("conectado al servidor");

        uaoiotClient.setUaoiotCallback((String messageType, String srcObject, int registerCount) -> {            
            
            if (messageType.equals("broadcast")) {
                System.out.print("Recibiendo Broadcast= [");
                for (int i = 0; i < registerCount; i++) {
                    System.out.print(uaoiotClient.getRegisterValue(i)+" | ");
                }
                System.out.println("]");
            }
            
            if (messageType.equals("unicast")) {
                System.out.print("Recibiendo Unicast= [");
                for (int i = 0; i < registerCount; i++) {
                    System.out.print(uaoiotClient.getRegisterValue(i)+",");
                }
                System.out.println("]");
            }
            
        });
        
    }

}
